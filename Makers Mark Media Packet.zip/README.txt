Contained within this file system are several images and recordings from both
our Brewsfor.me application, which was the precursor to our current work in progress,
as well as from said current work.
Some of the animations used on brewsfor.me will be brought into the current application,
which is why I felt they are relevent enough to be added to this media packet.
KEY:

Brewsfor.me-
brewspour:
    This displays the animation we created to showcase the beer being pulled from API.
    The information is generated, the beers stats are displayed, and the color of the pour 
    is modified based on the EBC value of the beer being passed in.
brewsfavorites:
    This was our admittedly basic favorites page, the animation at the top will be the only thing
    that will be considered for reuse.

Maker's Mark-
glass/glassstill:
    This is the rendering from the previous project, without the pouring animation. The pour may
    be added later.
makershome/still:
    This is the landing page, with each tap leading to the beerroute's page to further narrow the 
    options for the user. This list will naturally expand.
beerroutes:
    This is very much WIP, displaying the subcategory of each overarching beer type. This will be
    further styled and modified.

This is the work of less than a week for our team, and naturally things will continue to evolve. 
As you may have noticed, the backgrounds for each page are sections of the main page, and further
animation will be developed to accentuate that fact.
